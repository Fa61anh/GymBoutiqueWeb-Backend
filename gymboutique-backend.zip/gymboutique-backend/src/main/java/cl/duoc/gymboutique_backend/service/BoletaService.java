package cl.duoc.gymboutique_backend.service;

import cl.duoc.gymboutique_backend.dto.ItemCompraDTO;
import cl.duoc.gymboutique_backend.model.Boleta;
import cl.duoc.gymboutique_backend.model.DetalleBoleta;
import cl.duoc.gymboutique_backend.model.Producto;
import cl.duoc.gymboutique_backend.model.Usuario;
import cl.duoc.gymboutique_backend.repository.BoletaRepository;
import cl.duoc.gymboutique_backend.repository.ProductoRepository;
import cl.duoc.gymboutique_backend.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BoletaService {
    private final BoletaRepository boletaRepo;
    private final ProductoRepository productoRepo;
    private final UsuarioRepository usuarioRepo;

    @Transactional
    public Boleta generarBoleta(String correoUsuario, List<ItemCompraDTO> items) {
        if (items == null || items.isEmpty()) {
            throw new IllegalArgumentException("El carrito no puede estar vacío");
        }

        Usuario usuario = usuarioRepo.findByCorreo(correoUsuario)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Boleta boleta = Boleta.builder()
                .usuario(usuario)
                .fecha(LocalDateTime.now())
                .estado("PAGADA")
                .total(0)
                .build();

        int total = 0;
        for (ItemCompraDTO item : items) {
            Producto prod = productoRepo.findById(item.productoId())
                    .orElseThrow(() -> new RuntimeException("Producto no encontrado: " + item.productoId()));

            if (item.cantidad() <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
            }
            if (prod.getStock() < item.cantidad()) {
                throw new IllegalArgumentException("Stock insuficiente para " + prod.getName() + " (disponible: " + prod.getStock() + ")");
            }

            prod.setStock(prod.getStock() - item.cantidad());
            productoRepo.save(prod);

            int subtotal = prod.getPrice() * item.cantidad();
            DetalleBoleta detalle = DetalleBoleta.builder()
                    .boleta(boleta)
                    .producto(prod)
                    .cantidad(item.cantidad())
                    .precioUnitario(prod.getPrice())
                    .subtotal(subtotal)
                    .build();

            boleta.getDetalles().add(detalle);
            total += subtotal;
        }

        boleta.setTotal(total);
        return boletaRepo.save(boleta);
    }
}