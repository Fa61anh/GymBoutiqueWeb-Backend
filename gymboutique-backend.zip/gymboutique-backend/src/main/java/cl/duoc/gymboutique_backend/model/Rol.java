package cl.duoc.gymboutique_backend.model;

public enum Rol {
    ADMIN,
    VENDEDOR,
    CLIENTE
}