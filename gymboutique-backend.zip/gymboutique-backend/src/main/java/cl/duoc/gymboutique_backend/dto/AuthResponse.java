package cl.duoc.gymboutique_backend.dto;

public record AuthResponse(String token, String nombre, String correo, String rol) {}
