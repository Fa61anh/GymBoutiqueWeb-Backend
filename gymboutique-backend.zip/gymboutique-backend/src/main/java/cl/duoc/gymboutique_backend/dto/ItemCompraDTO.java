package cl.duoc.gymboutique_backend.dto;

public record ItemCompraDTO(String productoId, Integer cantidad) {}