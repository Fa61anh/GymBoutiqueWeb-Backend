package cl.duoc.gymboutique_backend.controller;

import cl.duoc.gymboutique_backend.dto.CompraRequest;
import cl.duoc.gymboutique_backend.model.Boleta;
import cl.duoc.gymboutique_backend.repository.BoletaRepository;
import cl.duoc.gymboutique_backend.service.BoletaService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/boletas")
@RequiredArgsConstructor
public class BoletaController {
    private final BoletaService boletaService;
    private final BoletaRepository boletaRepo;

    @PostMapping
    public ResponseEntity<?> crearCompra(@RequestBody CompraRequest req, Authentication auth) {
        try {
            Boleta nueva = boletaService.generarBoleta(auth.getName(), req.items());
            return ResponseEntity.status(HttpStatus.CREATED).body(nueva);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @GetMapping
    public List<Boleta> listarTodas() {
        return boletaRepo.findAll();
    }

    @GetMapping("/mis-compras")
    public List<Boleta> misCompras(Authentication auth) {
        return boletaRepo.findByUsuarioCorreoOrderByFechaDesc(auth.getName());
    }
}