package cl.duoc.gymboutique_backend.dto;

public record ProductoRequest(
        String id,
        String name,
        Integer price,
        Integer stock,
        String description,
        String image,
        String brand,
        Long categoriaId
) {}