package cl.duoc.gymboutique_backend.config;

import cl.duoc.gymboutique_backend.model.Categoria;
import cl.duoc.gymboutique_backend.model.Producto;
import cl.duoc.gymboutique_backend.model.Rol;
import cl.duoc.gymboutique_backend.model.Usuario;
import cl.duoc.gymboutique_backend.repository.CategoriaRepository;
import cl.duoc.gymboutique_backend.repository.ProductoRepository;
import cl.duoc.gymboutique_backend.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final UsuarioRepository usuarioRepo;
    private final CategoriaRepository categoriaRepo;
    private final ProductoRepository productoRepo;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (usuarioRepo.count() == 0) {
            usuarioRepo.save(Usuario.builder()
                    .nombre("Administrador Gym")
                    .correo("admin@gymboutique.cl")
                    .password(passwordEncoder.encode("admin123"))
                    .rol(Rol.ADMIN)
                    .build());

            usuarioRepo.save(Usuario.builder()
                    .nombre("Vendedor Tienda")
                    .correo("vendedor@gymboutique.cl")
                    .password(passwordEncoder.encode("vendedor123"))
                    .rol(Rol.VENDEDOR)
                    .build());

            usuarioRepo.save(Usuario.builder()
                    .nombre("Cliente Prueba")
                    .correo("cliente@gymboutique.cl")
                    .password(passwordEncoder.encode("cliente123"))
                    .rol(Rol.CLIENTE)
                    .build());
        }

        if (categoriaRepo.count() == 0) {
            Categoria suplementos = categoriaRepo.save(Categoria.builder()
                    .nombre("Suplementos")
                    .descripcion("Suplementación deportiva y nutrición")
                    .build());

            Categoria accesorios = categoriaRepo.save(Categoria.builder()
                    .nombre("Accesorios")
                    .descripcion("Equipamiento y accesorios de entrenamiento")
                    .build());

            Categoria membresias = categoriaRepo.save(Categoria.builder()
                    .nombre("Membresías")
                    .descripcion("Planes de suscripción al gimnasio IronStrong Fitness")
                    .build());

            productoRepo.save(Producto.builder()
                    .id("proteina")
                    .name("Proteína Whey")
                    .price(32990)
                    .stock(25)
                    .description("Nuestra Proteína Whey es la elección ideal para aquellos que buscan una fuente de proteína de alta calidad para optimizar su recuperación muscular después del entrenamiento.")
                    .image("/img/proteina.jpg")
                    .brand("IRONSTRONG")
                    .categoria(suplementos)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("botella")
                    .name("Botella Térmica")
                    .price(27990)
                    .stock(40)
                    .description("Nuestra Botella Térmica es la elección ideal para mantener tu bebida a la temperatura perfecta durante todo el día.")
                    .image("/img/botella.jpg")
                    .brand("IRONSTRONG")
                    .categoria(accesorios)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("cinturon")
                    .name("Cinturón de Entrenamiento")
                    .price(23990)
                    .stock(15)
                    .description("Nuestro Cinturón de Entrenamiento es la elección ideal para brindar soporte lumbar y estabilidad durante tus levantamientos pesados.")
                    .image("/img/cinturon.jpg")
                    .brand("IRONSTRONG")
                    .categoria(accesorios)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("straps")
                    .name("Straps de Entrenamiento")
                    .price(22990)
                    .stock(30)
                    .description("Nuestros Straps de Entrenamiento son la elección ideal para mejorar tu agarre y rendimiento en el gimnasio.")
                    .image("/img/straps.jpg")
                    .brand("IRONSTRONG")
                    .categoria(accesorios)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("basico")
                    .name("Plan Básico")
                    .price(19990)
                    .stock(999)
                    .description("Acceso ilimitado a la zona de máquinas de cardio y musculación en horario general.")
                    .image("/img/basico.jpg")
                    .brand("MEMBRESÍA MENSUAL")
                    .categoria(membresias)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("premium")
                    .name("Plan VIP / Premium")
                    .price(29990)
                    .stock(999)
                    .description("La experiencia completa con acceso total a todas las sedes, clases grupales y beneficios exclusivos.")
                    .image("/img/premium.jpg")
                    .brand("MEMBRESÍA MENSUAL")
                    .categoria(membresias)
                    .build());

            productoRepo.save(Producto.builder()
                    .id("anual")
                    .name("Plan Anual")
                    .price(249900)
                    .stock(999)
                    .description("Ahorra un porcentaje importante pagando tu año completo con permanencia preferencial.")
                    .image("/img/anual.jpg")
                    .brand("MEMBRESÍA ANUAL")
                    .categoria(membresias)
                    .build());
        }
    }
}