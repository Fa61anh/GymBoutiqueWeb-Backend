package cl.duoc.gymboutique_backend.controller;

import cl.duoc.gymboutique_backend.dto.ProductoRequest;
import cl.duoc.gymboutique_backend.model.Categoria;
import cl.duoc.gymboutique_backend.model.Producto;
import cl.duoc.gymboutique_backend.repository.CategoriaRepository;
import cl.duoc.gymboutique_backend.repository.ProductoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
@RequiredArgsConstructor
public class ProductoController {
    private final ProductoRepository productoRepo;
    private final CategoriaRepository categoriaRepo;

    @GetMapping
    public List<Producto> listar() {
        return productoRepo.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerPorId(@PathVariable String id) {
        return productoRepo.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<Producto> crear(@RequestBody ProductoRequest req) {
        Categoria cat = categoriaRepo.findById(req.categoriaId())
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));

        Producto p = Producto.builder()
                .id(req.id())
                .name(req.name())
                .price(req.price())
                .stock(req.stock())
                .description(req.description())
                .image(req.image())
                .brand(req.brand() != null ? req.brand() : "IRONSTRONG")
                .categoria(cat)
                .build();
        return ResponseEntity.status(HttpStatus.CREATED).body(productoRepo.save(p));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Producto> actualizar(@PathVariable String id, @RequestBody ProductoRequest req) {
        return productoRepo.findById(id).map(p -> {
            Categoria cat = categoriaRepo.findById(req.categoriaId()).orElse(p.getCategoria());
            p.setName(req.name());
            p.setPrice(req.price());
            p.setStock(req.stock());
            p.setDescription(req.description());
            p.setImage(req.image());
            p.setBrand(req.brand());
            p.setCategoria(cat);
            return ResponseEntity.ok(productoRepo.save(p));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable String id) {
        if (!productoRepo.existsById(id)) return ResponseEntity.notFound().build();
        productoRepo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}