package cl.duoc.gymboutique_backend.dto;

public record LoginRequest(String correo, String password) {}