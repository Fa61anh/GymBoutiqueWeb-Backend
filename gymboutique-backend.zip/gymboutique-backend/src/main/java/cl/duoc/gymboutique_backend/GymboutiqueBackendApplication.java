package cl.duoc.gymboutique_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GymboutiqueBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(GymboutiqueBackendApplication.class, args);
	}

}
