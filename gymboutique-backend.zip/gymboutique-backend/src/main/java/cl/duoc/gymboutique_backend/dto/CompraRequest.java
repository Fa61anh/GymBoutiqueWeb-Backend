package cl.duoc.gymboutique_backend.dto;

import java.util.List;

public record CompraRequest(List<ItemCompraDTO> items) {}