package cl.duoc.gymboutique_backend.dto;

public record RegistroRequest(String nombre, String correo, String password) {}