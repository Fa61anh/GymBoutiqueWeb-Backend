package cl.duoc.gymboutique_backend.repository;

import cl.duoc.gymboutique_backend.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductoRepository extends JpaRepository<Producto, String> {
}