package cl.duoc.gymboutique_backend.controller;

import cl.duoc.gymboutique_backend.dto.AuthResponse;
import cl.duoc.gymboutique_backend.dto.LoginRequest;
import cl.duoc.gymboutique_backend.dto.RegistroRequest;
import cl.duoc.gymboutique_backend.model.Rol;
import cl.duoc.gymboutique_backend.model.Usuario;
import cl.duoc.gymboutique_backend.repository.UsuarioRepository;
import cl.duoc.gymboutique_backend.security.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthController {
    private final UsuarioRepository usuarioRepo;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authManager;
    private final JwtService jwtService;

    @PostMapping("/registro")
    public ResponseEntity<?> registrar(@RequestBody RegistroRequest req) {
        if (usuarioRepo.existsByCorreo(req.correo())) {
            return ResponseEntity.badRequest().body("El correo ya está registrado");
        }
        Usuario nuevo = Usuario.builder()
                .nombre(req.nombre())
                .correo(req.correo())
                .password(passwordEncoder.encode(req.password()))
                .rol(Rol.CLIENTE)
                .build();
        usuarioRepo.save(nuevo);

        String token = jwtService.generarToken(nuevo.getCorreo(), nuevo.getRol().name(), nuevo.getNombre());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(new AuthResponse(token, nuevo.getNombre(), nuevo.getCorreo(), nuevo.getRol().name()));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        authManager.authenticate(new UsernamePasswordAuthenticationToken(req.correo(), req.password()));
        Usuario u = usuarioRepo.findByCorreo(req.correo()).orElseThrow();
        String token = jwtService.generarToken(u.getCorreo(), u.getRol().name(), u.getNombre());
        return ResponseEntity.ok(new AuthResponse(token, u.getNombre(), u.getCorreo(), u.getRol().name()));
    }
}