package cl.duoc.gymboutique_backend.controller;

import cl.duoc.gymboutique_backend.model.Categoria;
import cl.duoc.gymboutique_backend.repository.CategoriaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/categorias")
@RequiredArgsConstructor
public class CategoriaController {
    private final CategoriaRepository categoriaRepo;

    @GetMapping
    public List<Categoria> listar() {
        return categoriaRepo.findAll();
    }

    @PostMapping
    public ResponseEntity<Categoria> crear(@RequestBody Categoria c) {
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaRepo.save(c));
    }
}