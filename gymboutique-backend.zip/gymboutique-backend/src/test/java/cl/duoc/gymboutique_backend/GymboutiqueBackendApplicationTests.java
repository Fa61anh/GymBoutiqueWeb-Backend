package cl.duoc.gymboutique_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymboutiqueBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
